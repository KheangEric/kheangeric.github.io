self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "39a642c4910da49e7929",
    "url": "css/app.30b45c25.css"
  },
  {
    "revision": "8d57f12e8cc04b462e3f",
    "url": "css/chunk-vendors.094863c6.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "2d664e2ac0ec9e871ebbafe5e6990763",
    "url": "index.html"
  },
  {
    "revision": "2d12777f2703612307ff4a12f1b21899",
    "url": "ixarea-stats.js"
  },
  {
    "revision": "648c12bb1251505519f5d09e2cdae861",
    "url": "js/0.75478485.worker.js"
  },
  {
    "revision": "39a642c4910da49e7929",
    "url": "js/app.845f9f95.js"
  },
  {
    "revision": "8d57f12e8cc04b462e3f",
    "url": "js/chunk-vendors.e75bd7b3.js"
  },
  {
    "revision": "02995355b96ddf2519cd49f8aa73bb46",
    "url": "loader.js"
  },
  {
    "revision": "523b1a2eae8cb533fa6bd73831308f09",
    "url": "static/kgm.mask"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);